﻿window.ITINERARIES = [
  {
    "id": "newtaipei-pingxi-day",
    "title": "平溪鐵道放天燈一日遊",
    "region": "新北",
    "budget": "每人約 500-800 元",
    "distance": "近郊",
    "type": "山城",
    "transport": "台鐵/公車",
    "duration": "一日遊",
    "summary": "沿著平溪支線慢慢玩，適合群組沒有想法時快速決定的輕鬆路線。",
    "description": "從十分瀑布開始走到老街，再搭平溪支線到菁桐。路線不趕、拍照點多，也很適合 LINE 群組臨時揪團。",
    "bestFor": "想拍照、想走輕鬆山城、不想開車的同學。",
    "comment": "安排者覺得這條最適合第一次一起出去玩，花費低、交通清楚，而且每一站都很好聊天。",
    "spots": [
      {
        "name": "十分瀑布",
        "description": "先看瀑布與吊橋，當作一日遊開場。",
        "lat": 25.0492,
        "lng": 121.7871
      },
      {
        "name": "平溪老街",
        "description": "吃小吃、看鐵道街景，也可以安排放天燈。",
        "lat": 25.0256,
        "lng": 121.7398
      },
      {
        "name": "菁桐車站",
        "description": "木造車站與懷舊街景，適合收尾拍合照。",
        "lat": 25.0236,
        "lng": 121.7236
      }
    ]
  },
  {
    "id": "taipei-xinyi-day",
    "title": "台北信義夜景聚餐一日遊",
    "region": "台北",
    "budget": "每人約 800-1,500 元",
    "distance": "市區",
    "type": "都市",
    "transport": "捷運",
    "duration": "一日遊",
    "summary": "市區移動最簡單，白天逛展、晚上吃飯看夜景。",
    "description": "這條路線不用複雜轉乘，適合下課後延伸成半日遊，也能當作班級聚餐前後的活動安排。",
    "bestFor": "想在市區聚餐、拍夜景、交通越簡單越好的群組。",
    "comment": "預算可以彈性調整，便宜可以吃美食街，想正式一點可以訂信義區餐廳。",
    "spots": [
      {
        "name": "松山文創園區",
        "description": "看展、逛文創商店，集合點也好找。",
        "lat": 25.0438,
        "lng": 121.5606
      },
      {
        "name": "台北 101",
        "description": "信義區核心地標，吃飯與逛街選擇多。",
        "lat": 25.0339,
        "lng": 121.5645
      },
      {
        "name": "象山步道",
        "description": "傍晚走短步道看台北夜景。",
        "lat": 25.0271,
        "lng": 121.5764
      }
    ]
  },
  {
    "id": "newtaipei-jiufen-jinguashi-day",
    "title": "九份金瓜石山城一日遊",
    "region": "新北",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "山城",
    "transport": "公車",
    "duration": "一日遊",
    "summary": "經典山城路線，老街、博物館與海景一次排進去。",
    "description": "適合想要有明確目的地的群組，從九份老街吃小吃，再到金瓜石看礦業文化與山海景。",
    "bestFor": "想看山海景、吃老街小吃、喜歡復古街景的人。",
    "comment": "假日人多但氣氛很完整，建議下午出發、傍晚看山城燈景。",
    "spots": [
      {
        "name": "九份老街",
        "description": "小吃與茶樓集中，是最容易集合的主點。",
        "lat": 25.1097,
        "lng": 121.8452
      },
      {
        "name": "黃金博物館",
        "description": "了解金瓜石礦業歷史，也適合專題介紹。",
        "lat": 25.1081,
        "lng": 121.8579
      },
      {
        "name": "報時山步道",
        "description": "短步道可以看陰陽海與山景。",
        "lat": 25.1129,
        "lng": 121.8659
      }
    ]
  },
  {
    "id": "newtaipei-tamsui-day",
    "title": "淡水河岸夕陽一日遊",
    "region": "新北",
    "budget": "每人約 500-800 元",
    "distance": "近郊",
    "type": "河岸",
    "transport": "捷運",
    "duration": "一日遊",
    "summary": "捷運直達，吃老街、看夕陽，適合輕鬆出門。",
    "description": "淡水很適合預算有限的學生專題展示，交通和景點都簡單，從老街一路走到漁人碼頭。",
    "bestFor": "不想排行程太滿，只想吃東西、散步、看夕陽的群組。",
    "comment": "這條最穩，不太需要規劃能力也能玩得起來。",
    "spots": [
      {
        "name": "淡水老街",
        "description": "阿給、魚丸湯、伴手禮都集中在這裡。",
        "lat": 25.1697,
        "lng": 121.4406
      },
      {
        "name": "紅毛城",
        "description": "歷史建築與河岸景色，適合白天拍照。",
        "lat": 25.1754,
        "lng": 121.4329
      },
      {
        "name": "淡水漁人碼頭",
        "description": "傍晚看夕陽，作為一日遊收尾。",
        "lat": 25.1837,
        "lng": 121.4104
      }
    ]
  },
  {
    "id": "taipei-yangmingshan-day",
    "title": "陽明山花季步道一日遊",
    "region": "台北",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "自然",
    "transport": "公車",
    "duration": "一日遊",
    "summary": "不用離開台北也能有自然景觀，適合想換氣的群組。",
    "description": "安排陽明山花鐘、小油坑與擎天崗，整體有風景、有步道，也能避開純吃飯的單調感。",
    "bestFor": "想走路、拍自然景、但不想跑太遠的人。",
    "comment": "天氣好會很加分，建議 LINE Bot 未來可以加上天氣提醒。",
    "spots": [
      {
        "name": "陽明山花鐘",
        "description": "容易抵達的集合點，也能看季節花景。",
        "lat": 25.1553,
        "lng": 121.5481
      },
      {
        "name": "小油坑",
        "description": "地熱景觀很明顯，適合做路線亮點。",
        "lat": 25.1671,
        "lng": 121.5747
      },
      {
        "name": "擎天崗",
        "description": "草原視野開闊，適合傍晚前散步。",
        "lat": 25.1774,
        "lng": 121.5448
      }
    ]
  },
  {
    "id": "newtaipei-wulai-day",
    "title": "烏來溫泉老街一日遊",
    "region": "新北",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "自然",
    "transport": "公車",
    "duration": "一日遊",
    "summary": "老街、瀑布與溫泉氣氛都在同一區，適合慢慢走。",
    "description": "這條路線從烏來老街開始，搭配台車與瀑布，適合想要自然但又不要太硬的行程。",
    "bestFor": "想泡湯、想看瀑布、想吃老街食物的人。",
    "comment": "如果群組一直不知道去哪，烏來是很容易被接受的安全選項。",
    "spots": [
      {
        "name": "烏來老街",
        "description": "山產、小吃與溫泉商家集中。",
        "lat": 24.8633,
        "lng": 121.5512
      },
      {
        "name": "烏來台車站",
        "description": "有特色的短程交通體驗。",
        "lat": 24.8647,
        "lng": 121.5527
      },
      {
        "name": "烏來瀑布",
        "description": "視覺記憶點強，適合作為路線主景點。",
        "lat": 24.8494,
        "lng": 121.5517
      }
    ]
  },
  {
    "id": "keelung-harbor-food-day",
    "title": "基隆港邊美食一日遊",
    "region": "基隆",
    "budget": "每人約 500-800 元",
    "distance": "近郊",
    "type": "美食",
    "transport": "火車/公車",
    "duration": "一日遊",
    "summary": "港邊景色加夜市小吃，適合想吃東西的群組。",
    "description": "從正濱漁港拍彩色屋，再到和平島看海，最後用廟口夜市收尾，很適合美食導向推薦。",
    "bestFor": "想吃、想看海、想要交通不要太複雜的人。",
    "comment": "這條路線很適合做成 LINE Bot 的美食推薦案例。",
    "spots": [
      {
        "name": "正濱漁港",
        "description": "彩色屋與港邊風景，照片效果很好。",
        "lat": 25.1566,
        "lng": 121.7651
      },
      {
        "name": "和平島公園",
        "description": "海岸地形與步道，適合下午散步。",
        "lat": 25.1629,
        "lng": 121.7614
      },
      {
        "name": "基隆廟口夜市",
        "description": "晚餐選擇多，適合聚餐收尾。",
        "lat": 25.1283,
        "lng": 121.7434
      }
    ]
  },
  {
    "id": "taoyuan-daxi-day",
    "title": "桃園大溪老街一日遊",
    "region": "桃園",
    "budget": "每人約 500-800 元",
    "distance": "近郊",
    "type": "文化",
    "transport": "公車",
    "duration": "一日遊",
    "summary": "老街、橋景與慈湖串成一條輕文化路線。",
    "description": "大溪適合用來展示非台北的近郊推薦，景點密度高，資訊也容易整理。",
    "bestFor": "想吃豆干、看老街建築、安排半文化半散步的人。",
    "comment": "這條行程比較像班遊備案，花費不高又不會太累。",
    "spots": [
      {
        "name": "大溪老街",
        "description": "巴洛克立面與豆干店集中。",
        "lat": 24.8848,
        "lng": 121.2886
      },
      {
        "name": "大溪橋",
        "description": "連接河岸與老街，適合拍照。",
        "lat": 24.8819,
        "lng": 121.2869
      },
      {
        "name": "慈湖",
        "description": "湖景與綠地，適合行程後半段。",
        "lat": 24.8115,
        "lng": 121.2443
      }
    ]
  },
  {
    "id": "taoyuan-qingpu-day",
    "title": "青埔水族館購物一日遊",
    "region": "桃園",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "都市",
    "transport": "高鐵/捷運",
    "duration": "一日遊",
    "summary": "交通方便、室內景點多，雨天也能玩。",
    "description": "青埔區景點集中，水族館、商場與公園距離近，很適合需要降低天氣風險的推薦。",
    "bestFor": "想吹冷氣、想逛街、擔心下雨的群組。",
    "comment": "這條適合做成 LINE Bot 的雨天推薦範例。",
    "spots": [
      {
        "name": "Xpark",
        "description": "室內水族館，停留時間彈性。",
        "lat": 25.0168,
        "lng": 121.2148
      },
      {
        "name": "華泰名品城",
        "description": "購物與餐廳選擇集中。",
        "lat": 25.0143,
        "lng": 121.214
      },
      {
        "name": "青塘園",
        "description": "傍晚散步，讓行程不只在室內。",
        "lat": 25.0127,
        "lng": 121.2048
      }
    ]
  },
  {
    "id": "hsinchu-city-food-day",
    "title": "新竹市區小吃一日遊",
    "region": "新竹",
    "budget": "每人約 500-800 元",
    "distance": "市區",
    "type": "美食",
    "transport": "步行/公車",
    "duration": "一日遊",
    "summary": "市區景點集中，用小吃串起輕鬆行程。",
    "description": "新竹市區很適合做為學生專題中的美食推薦範例，景點與小吃距離近，步行可完成。",
    "bestFor": "想吃小吃、想少走交通、不想排行程太滿的人。",
    "comment": "這條推薦給只想吃東西但又想有幾個拍照點的群組。",
    "spots": [
      {
        "name": "新竹城隍廟",
        "description": "米粉、肉圓與小吃集中。",
        "lat": 24.8046,
        "lng": 120.9654
      },
      {
        "name": "東門市場",
        "description": "文青餐飲與傳統市場混合，很適合晚餐。",
        "lat": 24.804,
        "lng": 120.9652
      },
      {
        "name": "新竹公園",
        "description": "吃完散步，也能安排拍照。",
        "lat": 24.8052,
        "lng": 120.9792
      }
    ]
  },
  {
    "id": "miaoli-nanzhuang-day",
    "title": "苗栗南庄老街山線一日遊",
    "region": "苗栗",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "山城",
    "transport": "開車",
    "duration": "一日遊",
    "summary": "山城老街與湖景串起來，適合自駕小旅行。",
    "description": "南庄老街、桂花巷與向天湖適合安排成一條慢步調路線，讓網站看起來不只推薦都市景點。",
    "bestFor": "有車、想要山線風景、喜歡老街與自然的人。",
    "comment": "這條比較適合有人願意開車，未來 LINE Bot 可依交通方式先過濾。",
    "spots": [
      {
        "name": "南庄老街",
        "description": "老街小吃與桂花香氣是主要特色。",
        "lat": 24.6004,
        "lng": 121.0003
      },
      {
        "name": "桂花巷",
        "description": "短短一段但很有南庄代表性。",
        "lat": 24.5991,
        "lng": 121.0012
      },
      {
        "name": "向天湖",
        "description": "湖景與賽夏族文化，適合作為自然段落。",
        "lat": 24.5354,
        "lng": 121.0311
      }
    ]
  },
  {
    "id": "taichung-art-cafe-day",
    "title": "台中審計新村文青一日遊",
    "region": "台中",
    "budget": "每人約 800-1,500 元",
    "distance": "市區",
    "type": "文化",
    "transport": "公車",
    "duration": "一日遊",
    "summary": "市區文創、咖啡與美術館，行程輕鬆但很完整。",
    "description": "台中市區路線適合做成推薦卡片，因為地點集中、交通好理解，也符合學生出遊常見需求。",
    "bestFor": "想逛文創市集、喝咖啡、拍照的人。",
    "comment": "這條路線比較漂亮，適合拿來當專題展示的輪播第一批資料。",
    "spots": [
      {
        "name": "審計新村",
        "description": "文創小店與市集，適合午後集合。",
        "lat": 24.1456,
        "lng": 120.6626
      },
      {
        "name": "勤美草悟道",
        "description": "綠廊、商場與咖啡店很多。",
        "lat": 24.1511,
        "lng": 120.663
      },
      {
        "name": "國立台灣美術館",
        "description": "免費展覽與大片草地，適合行程前半段。",
        "lat": 24.1415,
        "lng": 120.6635
      }
    ]
  },
  {
    "id": "taichung-gaomei-day",
    "title": "高美濕地夕陽一日遊",
    "region": "台中",
    "budget": "每人約 500-800 元",
    "distance": "近郊",
    "type": "自然",
    "transport": "公車/開車",
    "duration": "一日遊",
    "summary": "下午出發到海線，重點放在夕陽與濕地風景。",
    "description": "高美濕地是中部經典夕陽點，可搭配市區或漁港，適合網站展示地圖上不同區域的推薦。",
    "bestFor": "想看夕陽、想拍照、可以接受交通時間的人。",
    "comment": "這條要注意潮汐與天氣，之後可以串接天氣 API 做加分功能。",
    "spots": [
      {
        "name": "台中火車站",
        "description": "作為集合與轉乘點。",
        "lat": 24.1368,
        "lng": 120.685
      },
      {
        "name": "梧棲漁港",
        "description": "可以先吃海鮮或簡單逛逛。",
        "lat": 24.2935,
        "lng": 120.5216
      },
      {
        "name": "高美濕地",
        "description": "看夕陽與風車，是整條路線主景點。",
        "lat": 24.312,
        "lng": 120.5495
      }
    ]
  },
  {
    "id": "changhua-lukang-day",
    "title": "彰化鹿港老街一日遊",
    "region": "彰化",
    "budget": "每人約 500-800 元",
    "distance": "近郊",
    "type": "文化",
    "transport": "公車",
    "duration": "一日遊",
    "summary": "廟宇、老街與傳統小吃，適合文化型行程。",
    "description": "鹿港景點集中，非常適合用 marker 呈現一日遊停靠點，資訊清楚又不複雜。",
    "bestFor": "喜歡老街、廟宇、傳統點心的人。",
    "comment": "這條很適合做成長輩也能接受的推薦。",
    "spots": [
      {
        "name": "鹿港老街",
        "description": "紅磚街屋與小吃集中。",
        "lat": 24.0574,
        "lng": 120.4345
      },
      {
        "name": "鹿港天后宮",
        "description": "鹿港代表性廟宇，也是明確地標。",
        "lat": 24.0599,
        "lng": 120.4312
      },
      {
        "name": "摸乳巷",
        "description": "短巷景點，適合穿插在步行路線。",
        "lat": 24.0568,
        "lng": 120.4328
      }
    ]
  },
  {
    "id": "nantou-sunmoonlake-day",
    "title": "南投日月潭環湖一日遊",
    "region": "南投",
    "budget": "每人約 1,500-2,500 元",
    "distance": "遠程",
    "type": "自然",
    "transport": "開車",
    "duration": "一日遊",
    "summary": "湖景、碼頭與自行車道，適合整天型行程。",
    "description": "日月潭可安排搭船或環湖，景點間距適中，很適合網站展示較遠的一日遊推薦。",
    "bestFor": "願意早出門、想看湖景、想要完整旅行感的人。",
    "comment": "這條預算較高，但最有一日遊完整感。",
    "spots": [
      {
        "name": "水社碼頭",
        "description": "集合、搭船與租車都方便。",
        "lat": 23.8529,
        "lng": 120.9057
      },
      {
        "name": "伊達邵碼頭",
        "description": "小吃與湖景，適合作為午餐點。",
        "lat": 23.8489,
        "lng": 120.9325
      },
      {
        "name": "向山遊客中心",
        "description": "建築與湖景很適合拍照。",
        "lat": 23.8543,
        "lng": 120.9391
      }
    ]
  },
  {
    "id": "chiayi-alishan-day",
    "title": "嘉義阿里山森林一日遊",
    "region": "嘉義",
    "budget": "每人約 1,500-2,500 元",
    "distance": "遠程",
    "type": "自然",
    "transport": "開車",
    "duration": "一日遊",
    "summary": "森林步道與高山景觀，適合偏戶外的推薦。",
    "description": "阿里山適合做為每人約 1,500-2,500 元遠程行程，雖然交通時間較長，但景點特色很明確。",
    "bestFor": "想看森林、喜歡自然景觀、能接受早起的人。",
    "comment": "這條比較像進階推薦，LINE Bot 可在使用者願意遠行時才推。",
    "spots": [
      {
        "name": "阿里山森林遊樂區",
        "description": "主要景點入口，森林步道集中。",
        "lat": 23.5106,
        "lng": 120.8051
      },
      {
        "name": "祝山觀日平台",
        "description": "經典日出點，也可作為高山景觀代表。",
        "lat": 23.5123,
        "lng": 120.8138
      },
      {
        "name": "沼平車站",
        "description": "森林鐵路與步道銜接點。",
        "lat": 23.5145,
        "lng": 120.8131
      }
    ]
  },
  {
    "id": "tainan-history-food-day",
    "title": "台南古蹟小吃一日遊",
    "region": "台南",
    "budget": "每人約 500-800 元",
    "distance": "市區",
    "type": "美食",
    "transport": "步行/公車",
    "duration": "一日遊",
    "summary": "古蹟和小吃密度高，最適合靠步行完成。",
    "description": "台南市區能用少量交通完成多個景點，適合展示美食與文化混合推薦。",
    "bestFor": "想吃小吃、喜歡古蹟、想慢慢走的人。",
    "comment": "這條路線很適合學生，因為花費低、景點密集。",
    "spots": [
      {
        "name": "赤崁樓",
        "description": "台南代表古蹟，適合當作起點。",
        "lat": 22.9973,
        "lng": 120.202
      },
      {
        "name": "國華街",
        "description": "小吃密度高，適合午餐與點心。",
        "lat": 22.9948,
        "lng": 120.1967
      },
      {
        "name": "神農街",
        "description": "夜間燈光與老屋氛圍，適合收尾。",
        "lat": 22.997,
        "lng": 120.196
      }
    ]
  },
  {
    "id": "kaohsiung-harbor-day",
    "title": "高雄港灣輕軌一日遊",
    "region": "高雄",
    "budget": "每人約 800-1,500 元",
    "distance": "市區",
    "type": "都市",
    "transport": "輕軌",
    "duration": "一日遊",
    "summary": "用輕軌串起港灣景點，移動清楚又有城市感。",
    "description": "高雄港區景點適合用互動地圖展示，路線沿海，能看到城市與海港的轉換。",
    "bestFor": "想看港景、想搭輕軌、想吃晚餐看夜景的人。",
    "comment": "這條很適合炫技展示，因為路線在地圖上很直覺。",
    "spots": [
      {
        "name": "駁二藝術特區",
        "description": "展覽、文創與港邊倉庫景觀。",
        "lat": 22.6206,
        "lng": 120.2816
      },
      {
        "name": "西子灣",
        "description": "看海、看夕陽，也能安排輕食。",
        "lat": 22.6248,
        "lng": 120.2646
      },
      {
        "name": "高雄流行音樂中心",
        "description": "晚上燈光漂亮，適合作為收尾。",
        "lat": 22.6175,
        "lng": 120.2934
      }
    ]
  },
  {
    "id": "kaohsiung-fo-guang-day",
    "title": "佛光山文化一日遊",
    "region": "高雄",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "文化",
    "transport": "公車/開車",
    "duration": "一日遊",
    "summary": "文化景點與老街搭配，適合想走不一樣路線的群組。",
    "description": "佛光山區域地標明顯，加上旗山老街能補足餐飲與逛街需求。",
    "bestFor": "想走文化路線、想拍大地標、不想只逛市區的人。",
    "comment": "這條適合當作高雄近郊推薦，和港灣路線形成對比。",
    "spots": [
      {
        "name": "佛陀紀念館",
        "description": "大型地標，視覺辨識度高。",
        "lat": 22.7511,
        "lng": 120.4458
      },
      {
        "name": "佛光山大佛城",
        "description": "文化景點核心，適合停留拍照。",
        "lat": 22.7493,
        "lng": 120.444
      },
      {
        "name": "旗山老街",
        "description": "香蕉甜點與老街小吃，可作為晚餐點。",
        "lat": 22.8861,
        "lng": 120.4828
      }
    ]
  },
  {
    "id": "pingtung-kenting-day",
    "title": "屏東墾丁海線一日遊",
    "region": "屏東",
    "budget": "每人約 1,500-2,500 元",
    "distance": "遠程",
    "type": "海線",
    "transport": "開車",
    "duration": "一日遊",
    "summary": "海景、燈塔與墾丁大街，適合南部長距離出遊。",
    "description": "墾丁路線距離較遠，但很有旅行感，適合作為每人約 1,500-2,500 元遠程推薦。",
    "bestFor": "想看海、想拍照、可以接受長時間移動的人。",
    "comment": "這條最好排早出晚歸，LINE Bot 未來可提醒交通時間。",
    "spots": [
      {
        "name": "船帆石",
        "description": "經典海岸地標，適合拍照。",
        "lat": 21.9601,
        "lng": 120.7641
      },
      {
        "name": "鵝鑾鼻公園",
        "description": "燈塔與草地景觀，是海線重點。",
        "lat": 21.902,
        "lng": 120.8528
      },
      {
        "name": "墾丁大街",
        "description": "晚餐與夜市，適合作為結尾。",
        "lat": 21.9442,
        "lng": 120.7995
      }
    ]
  },
  {
    "id": "yilan-jiaoxi-day",
    "title": "宜蘭礁溪溫泉一日遊",
    "region": "宜蘭",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "自然",
    "transport": "火車/公車",
    "duration": "一日遊",
    "summary": "火車可到，溫泉、公園與市區吃飯都方便。",
    "description": "礁溪是宜蘭很適合學生的路線，交通不算困難，且天氣冷或下雨也可以調整成泡湯行程。",
    "bestFor": "想泡湯、想搭火車、想短距離出遊的人。",
    "comment": "這條非常適合群組臨時說想放鬆的時候推薦。",
    "spots": [
      {
        "name": "礁溪溫泉公園",
        "description": "溫泉氛圍明確，適合當作起點。",
        "lat": 24.8272,
        "lng": 121.7752
      },
      {
        "name": "湯圍溝溫泉公園",
        "description": "市區中心點，周邊餐飲多。",
        "lat": 24.8328,
        "lng": 121.7568
      },
      {
        "name": "宜蘭車站",
        "description": "幾米廣場與轉乘點，收尾好安排。",
        "lat": 24.7552,
        "lng": 121.7563
      }
    ]
  },
  {
    "id": "yilan-toucheng-day",
    "title": "頭城海線咖啡一日遊",
    "region": "宜蘭",
    "budget": "每人約 800-1,500 元",
    "distance": "近郊",
    "type": "海線",
    "transport": "火車",
    "duration": "一日遊",
    "summary": "老街、博物館與海灘，適合放空型一日遊。",
    "description": "頭城海線適合想看海但不想跑太遠的群組，搭火車也能安排。",
    "bestFor": "想看海、想喝咖啡、想慢慢走的人。",
    "comment": "這條行程氣氛比較放鬆，很適合做成週末推薦。",
    "spots": [
      {
        "name": "頭城老街",
        "description": "先吃點東西，作為路線開場。",
        "lat": 24.8586,
        "lng": 121.8232
      },
      {
        "name": "蘭陽博物館",
        "description": "建築造型明顯，適合拍照與看展。",
        "lat": 24.8692,
        "lng": 121.8348
      },
      {
        "name": "外澳海灘",
        "description": "看海、喝咖啡，作為放鬆收尾。",
        "lat": 24.8834,
        "lng": 121.8422
      }
    ]
  },
  {
    "id": "hualien-ocean-day",
    "title": "花蓮七星潭海景一日遊",
    "region": "花蓮",
    "budget": "每人約 800-1,500 元",
    "distance": "遠程",
    "type": "海線",
    "transport": "火車/租車",
    "duration": "一日遊",
    "summary": "花蓮市區加七星潭，適合東部海景推薦。",
    "description": "這條路線讓網站不只集中在西半部，能展示東部景點與租車型行程。",
    "bestFor": "想看海、想拍照、願意搭火車到花蓮的人。",
    "comment": "這條比較像旅行參考資料，之後可放真實使用者分享。",
    "spots": [
      {
        "name": "七星潭",
        "description": "花蓮代表海景，適合拍照與散步。",
        "lat": 24.0287,
        "lng": 121.6286
      },
      {
        "name": "松園別館",
        "description": "歷史建築與市區景觀。",
        "lat": 23.9871,
        "lng": 121.6224
      },
      {
        "name": "東大門夜市",
        "description": "晚餐選擇多，適合一日遊收尾。",
        "lat": 23.9738,
        "lng": 121.6148
      }
    ]
  },
  {
    "id": "hualien-taroko-day",
    "title": "太魯閣峽谷一日遊",
    "region": "花蓮",
    "budget": "每人約 1,500-2,500 元",
    "distance": "遠程",
    "type": "自然",
    "transport": "包車",
    "duration": "一日遊",
    "summary": "峽谷地形非常有特色，適合做高辨識度推薦。",
    "description": "太魯閣適合用在網站展示中，因為地點很有代表性，且和城市聚餐型行程差異明顯。",
    "bestFor": "想看壯觀自然景觀、願意包車或租車的人。",
    "comment": "這條不一定適合臨時出發，但很適合當作收藏型行程。",
    "spots": [
      {
        "name": "太魯閣牌樓",
        "description": "進入太魯閣的代表地標。",
        "lat": 24.1587,
        "lng": 121.6212
      },
      {
        "name": "長春祠",
        "description": "峽谷中的經典景點。",
        "lat": 24.1615,
        "lng": 121.611
      },
      {
        "name": "燕子口",
        "description": "峽谷岩壁景觀，行程亮點很明確。",
        "lat": 24.1609,
        "lng": 121.6044
      }
    ]
  },
  {
    "id": "taitung-city-sea-day",
    "title": "台東市區海風一日遊",
    "region": "台東",
    "budget": "每人約 800-1,500 元",
    "distance": "遠程",
    "type": "海線",
    "transport": "鐵路/機車",
    "duration": "一日遊",
    "summary": "台東市區景點加海邊，適合慢步調旅行。",
    "description": "台東路線可以讓資料看起來更完整，未來若收集使用者行程，也能放入東部旅行分享。",
    "bestFor": "想慢慢玩、想看海、願意租機車的人。",
    "comment": "這條主打放鬆，不適合塞太多點，所以三站剛剛好。",
    "spots": [
      {
        "name": "台東森林公園",
        "description": "市區大綠地，可騎腳踏車。",
        "lat": 22.7625,
        "lng": 121.1607
      },
      {
        "name": "台東海濱公園",
        "description": "看海、看地標，適合傍晚散步。",
        "lat": 22.7536,
        "lng": 121.1635
      },
      {
        "name": "鐵花村",
        "description": "市區音樂與市集空間，適合晚上收尾。",
        "lat": 22.7525,
        "lng": 121.1481
      }
    ]
  }
];

